﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Command_Line_Menus
{
    public class Menus
    {
        /** Declare Constants: **/

        string SELECTION_TEXT = "Please make a selection (1-{0}, or 0 to return to main menu): ";
        string VALIDITY_CATCH = "== I'm sorry, your input was not recognised. Please enter a valid input. ==";


        /** Declare Variables: **/

        // Interface staples:
        bool inputValid;
        string textInput;
        int optionCount;
        //public static int validFields = 0;


        /** Methods: **/

        void Make_Menu(string menuText, int numOptions)
        {
            // Constants:
            string HEADER_TEXT = "Welcome to the Tool Library";
            
            // Set optionCount variable:
            optionCount = numOptions;

            // Print Menu:
            Console.WriteLine(HEADER_TEXT);
            Console.WriteLine(menuText);
            Console.Write(SELECTION_TEXT, numOptions);
        }

        public void Main_Menu()
        {
            // Menu Text Constant:
            string MAIN_TEXT = "===========Main Menu===========\n" +
                           "1. Staff Login\n" +
                           "2. Member Login\n" +
                           "0. Exit\n" +
                           "===============================\n";

            // Reset inputValid and textInput:
            inputValid = false;
            textInput = "";

            // Print menu text:
            Make_Menu(MAIN_TEXT, 2);

            // Read users keypress:
            textInput = Inputs.Get_Key_Press();

            // Check if user input is vaild and change to menu:
            while (!inputValid)
            {
                if (textInput == "1")
                {
                    Console.WriteLine();
                    Staff_Menu();
                    inputValid = true;
                }
                else if (textInput == "2")
                {
                    Console.WriteLine();
                    Member_Menu();
                    inputValid = true;
                }
                else if (textInput == "0")
                {
                    // Close console:
                    Environment.Exit(0);
                }
                else
                {
                    // Reset textInput:
                    textInput = "";

                    // Ask to enter valid option:
                    Console.WriteLine();
                    Console.WriteLine(VALIDITY_CATCH);
                    Console.WriteLine();
                    Console.Write(SELECTION_TEXT);

                    // Read users keypress:
                    textInput = Inputs.Get_Key_Press();
                }
            }

        }

        void Staff_Menu()
        {
            // Menu Text Constant:
            string STAFF_TEXT = "================Staff Menu================\n" +
                           "1. Add a new tool\n" +
                           "2. Add new pieces of an existing tool\n" +
                           "3. Remove some pieces of a tool\n" +
                           "4. Register a new member\n" +
                           "5. Remove a member\n" +
                           "6. Find the contact number of a member\n" +
                           "0. Return to main menu\n" +
                           "==========================================\n";



            // Reset inputValid and textInput:
            inputValid = false;
            textInput = "";

            // Print menu text:
            Make_Menu(STAFF_TEXT, 6);

            // Read users keypress:
            textInput = Inputs.Get_Key_Press();

            // Check if user input is vaild and change to menu:
            while (!inputValid)
            {
                if (textInput == "1")
                {
                    // Add a new tool

                    inputValid = true;
                }
                else if (textInput == "2")
                {
                    // Add new pieces of an existing tool

                    inputValid = true;
                }
                else if (textInput == "3")
                {
                    // Remove some pieces of a tool

                    inputValid = true;
                }
                else if (textInput == "4")
                {
                    // Register a new member

                    inputValid = true;
                }
                else if (textInput == "5")
                {
                    // Remove a member

                    inputValid = true;
                }
                else if (textInput == "6")
                {
                    // Find the contacct number of a member

                    inputValid = true;
                }
                else if (textInput == "0")
                {
                    // Return to main menu:
                    Console.WriteLine();
                    Main_Menu();
                    inputValid = true;
                }
                else
                {
                    // Reset textInput:
                    textInput = "";

                    // Ask to enter valid option:
                    Console.WriteLine();
                    Console.WriteLine(VALIDITY_CATCH);
                    Console.WriteLine();
                    Console.Write(SELECTION_TEXT);

                    // Read users keypress:
                    textInput = Inputs.Get_Key_Press();
                }
            }
        }

        void Member_Menu()
        {
            // Menu Text Constant:
            string MEMBER_TEXT = "===============Member Menu===============\n" +
                             "1. Display all the tools of a tool type\n" +
                             "2. Borrow a tool\n" +
                             "3. Return a tool\n" +
                             "4. List all the tools that I am renting\n" +
                             "5. Display top three (3) most frequentely rented tools\n" +
                             "0. Return to main menu\n" +
                             "=========================================";



            // Reset inputValid and textInput:
            inputValid = false;
            textInput = "";

            // Print menu text:
            Make_Menu(MEMBER_TEXT, 5);

            // Read users keypress:
            textInput = Inputs.Get_Key_Press();

            // Check if user input is vaild and change to menu:
            while (!inputValid)
            {
                if (textInput == "1")
                {
                    // Display all the tools of a tool type

                    inputValid = true;
                }
                else if (textInput == "2")
                {
                    // Borrow a tool

                    inputValid = true;
                }
                else if (textInput == "3")
                {
                    // Return a tool

                    inputValid = true;
                }
                else if (textInput == "4")
                {
                    // List all tools that i am renting

                    inputValid = true;
                }
                else if (textInput == "5")
                {
                    // Display top 3 most frequentely rented tools

                    inputValid = true;
                }
                else if (textInput == "0")
                {
                    // Return to main menu:
                    Console.WriteLine();
                    Main_Menu();
                    inputValid = true;
                }
                else
                {
                    // Reset textInput:
                    textInput = "";

                    // Ask to enter valid option:
                    Console.WriteLine();
                    Console.WriteLine(VALIDITY_CATCH);
                    Console.WriteLine();
                    Console.Write(SELECTION_TEXT);

                    // Read users keypress:
                    textInput = Inputs.Get_Key_Press();
                }
            }
        }

    }
}
