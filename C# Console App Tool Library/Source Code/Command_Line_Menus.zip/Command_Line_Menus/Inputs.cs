﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Command_Line_Menus
{
    class Inputs
    {

        public static string Get_Key_Press()
        {
            // Variables:
            string textInput;
            ConsoleKeyInfo readKeyResult = Console.ReadKey(true);

            // Read input into textInput:
            textInput = (readKeyResult.KeyChar).ToString();
            // Print key pressed to console:
            Console.WriteLine(textInput);

            return textInput;
        } 
    }
}
